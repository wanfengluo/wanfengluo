package com.example.fakelogistics;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class JisuanqiActivity extends AppCompatActivity implements View.OnClickListener {
    Button zero;
    Button one;
    Button two;
    Button three;
    Button four;
    Button five;
    Button six;
    Button seven;
    Button eight;
    Button nine;
    Button point;
    Button clear;
    Button add;
    Button substraction;
    Button mulitipliction;
    Button division;
    Button root;
    Button surplus;
    Button equal;
    Button delete;
    TextView theFirstView;
    TextView theOptionView;
    TextView theSecondView;
    TextView theEqualView;
    TextView theAnswerView ;
    String option = "";
    String str1 = "",str2 = "";
    double number1 ,number2;
    int answerFlag = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jisuanqi);
        initView();  //初始化布局
    }

    @Override
    public void onClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.zero || viewId == R.id.one || viewId == R.id.two || viewId == R.id.three ||
                viewId == R.id.four || viewId == R.id.five || viewId == R.id.six || viewId == R.id.seven ||
                viewId == R.id.eight || viewId == R.id.nine) {

            if (answerFlag == 0) {
                if (option.equals("")) {
                    str1 = str1 + ((Button) view).getText().toString();
                    theFirstView.setText(str1);
                } else {
                    str2 = str2 + ((Button) view).getText().toString();
                    theSecondView.setText(str2);
                }
            }

            if (answerFlag == 1) {
                clear();
                answerFlag = 0;
                str1 = str1 + ((Button) view).getText().toString();
                theFirstView.setText(str1);
            }

        } else if (viewId == R.id.point) {
            if (!str1.equals("") && option.equals("")) {
                str1 = str1 + ((Button) view).getText().toString();
                theFirstView.setText(str1);
            } else if (!option.equals("") && !str2.equals("")) {
                str2 = str2 + ((Button) view).getText().toString();
                theSecondView.setText(str2);
            }

        } else if (viewId == R.id.add) {
            option = "+";
            theOptionView.setText("+");

        } else if (viewId == R.id.substraction) {
            option = "-";
            theOptionView.setText("-");

        } else if (viewId == R.id.mulitipliction) {
            option = "×";
            theOptionView.setText("×");

        } else if (viewId == R.id.division) {
            option = "÷";
            theOptionView.setText("÷");

        } else if (viewId == R.id.surplus) {
            option = "%";
            theOptionView.setText("%");

        } else if (viewId == R.id.root) {
            if (str1.equals("")) {
                option = "√";
                theOptionView.setText("√");
            }

        } else if (viewId == R.id.clear) {
            clear();

        } else if (viewId == R.id.delete) {
            if (theAnswerView.getText().toString().equals("")) {
                if (!theSecondView.getText().toString().equals("")) {
                    int length = str2.length();
                    if (length == 1) {
                        theSecondView.setText("");
                    } else {
                        str2 = str2.substring(0, length - 1);
                        theSecondView.setText(str2);
                    }
                } else if (theSecondView.getText().toString().equals("") && !theOptionView.getText().toString().equals("")) {
                    theOptionView.setText("");
                } else if (theSecondView.getText().toString().equals("") && theAnswerView.getText().toString().equals("") &&
                        !theFirstView.getText().toString().equals("")) {
                    int length = str1.length();
                    if (length == 1) {
                        theFirstView.setText("");
                    } else {
                        str1 = str1.substring(0, length - 1);
                        theFirstView.setText(str1);
                    }
                }
            }

        } else if (viewId == R.id.equal) {
            theEqualView.setText("=");
            answerFlag = 1;

            double number1 = Double.parseDouble(theFirstView.getText().toString());
            double number2 = Double.parseDouble(theSecondView.getText().toString());

            if (option.equals("+")) {
                theAnswerView.setText((number1 + number2) + "");
            } else if (option.equals("-")) {
                theAnswerView.setText((number1 - number2) + "");
            } else if (option.equals("×")) {
                theAnswerView.setText((number1 * number2) + "");
            } else if (option.equals("÷")) {
                if (number2 == 0) {
                    theAnswerView.setText("错误");
                } else {
                    theAnswerView.setText((number1 / number2) + "");
                }
            } else if (option.equals("√")) {
                theAnswerView.setText(Math.sqrt(number2) + "");
            } else if (option.equals("%")) {
                theAnswerView.setText((number1 % number2) + "");
            }
        }
    }


    public void initView(){
        zero = (Button)findViewById(R.id.zero);
        one = (Button)findViewById(R.id.one);
        two = (Button)findViewById(R.id.two);
        three = (Button)findViewById(R.id.three);
        four = (Button)findViewById(R.id.four);
        five = (Button)findViewById(R.id.five);
        six = (Button)findViewById(R.id.six);
        seven = (Button)findViewById(R.id.seven);
        eight = (Button)findViewById(R.id.eight);
        nine = (Button)findViewById(R.id.nine);
        point = (Button)findViewById(R.id.point);
        clear = (Button)findViewById(R.id.clear);
        add = (Button)findViewById(R.id.add);
        substraction = (Button)findViewById(R.id.substraction);
        mulitipliction = (Button)findViewById(R.id.mulitipliction);
        division = (Button)findViewById(R.id.division);
        root = (Button)findViewById(R.id.root);
        surplus = (Button)findViewById(R.id.surplus);
        equal = (Button)findViewById(R.id.equal);
        delete = (Button)findViewById(R.id.delete);
        theFirstView = (TextView)findViewById(R.id.the_first_number);
        theOptionView = (TextView)findViewById(R.id.the_option);
        theSecondView = (TextView)findViewById(R.id.the_second_number);
        theEqualView = (TextView)findViewById(R.id.the_equal);
        theAnswerView = (TextView)findViewById(R.id.the_answer);

        zero.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        point.setOnClickListener(this);
        clear.setOnClickListener(this);
        add.setOnClickListener(this);
        substraction.setOnClickListener(this);
        mulitipliction.setOnClickListener(this);
        division.setOnClickListener(this);
        root.setOnClickListener(this);
        surplus.setOnClickListener(this);
        equal.setOnClickListener(this);
        delete.setOnClickListener(this);
        theFirstView.setOnClickListener(this);
        theOptionView.setOnClickListener(this);
        theEqualView.setOnClickListener(this);
        theSecondView.setOnClickListener(this);
        theAnswerView.setOnClickListener(this);
    }

    public void clear(){
        str1 = "";
        str2 = "";
        theFirstView.setText("");
        theSecondView.setText("");
        theOptionView.setText("");
        theEqualView.setText("");
        theAnswerView.setText("");
        option = "";
    }


}