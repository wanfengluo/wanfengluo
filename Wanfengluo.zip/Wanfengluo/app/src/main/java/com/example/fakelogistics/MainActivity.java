package com.example.fakelogistics;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public StudyRoom studyRoom;
    private StudyRoom seatView;
    private Button btnJisuanqi;

    private Spinner buildingSpinner;
    private Spinner roomSpinner;
    private Button timeButton;
    private TextView selectedTimeTextView;
    private Button saveButton;
    private int selectedHour;
    private int selectedMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        studyRoom = (StudyRoom) findViewById(R.id.seatView);

        studyRoom.setMaxSelected(1);//设置最多选中
        studyRoom.setSeatChecker(new StudyRoom.SeatChecker() {

            @Override
            public boolean isValidSeat(int row, int column) {
                return true;
            }

            @Override
            public boolean isBook(int row, int column) {
                if (row == 6 && column == 6) {
                    return true;
                }
                return false;
            }

            @Override
            public void checked(int row, int column) {

            }

            @Override
            public void unCheck(int row, int column) {

            }

            @Override
            public String[] checkedSeatTxt(int row, int column) {
                return null;
            }

        });
        studyRoom.setData(10, 15);

        initView();


        btnJisuanqi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, JisuanqiActivity.class));
            }
        });



        buildingSpinner = findViewById(R.id.buildingSpinner);
        roomSpinner = findViewById(R.id.roomSpinner);
        timeButton = findViewById(R.id.timeButton);
        selectedTimeTextView = findViewById(R.id.selectedTimeTextView);
        saveButton = findViewById(R.id.saveButton);

        // Setting up building spinner
        ArrayAdapter<CharSequence> buildingAdapter = ArrayAdapter.createFromResource(this,
                R.array.buildings_array, android.R.layout.simple_spinner_item);
        buildingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        buildingSpinner.setAdapter(buildingAdapter);

        buildingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String building = buildingSpinner.getSelectedItem().toString();
                String room = roomSpinner.getSelectedItem().toString();

                String screenName = "楼号: " + building + ",房间号: " + room + "自习室";
                studyRoom.setScreenName(screenName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                String building = buildingSpinner.getSelectedItem().toString();
                String room = roomSpinner.getSelectedItem().toString();

                String screenName = "楼号: " + building + ",房间号: " + room + "自习室";
                studyRoom.setScreenName(screenName);
            }

        });

        // Setting up room spinner
        ArrayAdapter<CharSequence> roomAdapter = ArrayAdapter.createFromResource(this,
                R.array.rooms_array, android.R.layout.simple_spinner_item);
        roomAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomSpinner.setAdapter(roomAdapter);
        roomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String building = buildingSpinner.getSelectedItem().toString();
                String room = roomSpinner.getSelectedItem().toString();

                String screenName = "楼号: " + building + ",房间号: " + room + "自习室";
                studyRoom.setScreenName(screenName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                String building = buildingSpinner.getSelectedItem().toString();
                String room = roomSpinner.getSelectedItem().toString();

                String screenName = "楼号: " + building + ",房间号: " + room + "自习室";
                studyRoom.setScreenName(screenName);
            }

        });

        // Time button click listener
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get current time
                final Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        (view, hourOfDay, minuteOfHour) -> {
                            selectedHour = hourOfDay;
                            selectedMinute = minuteOfHour;
                            selectedTimeTextView.setText(String.format("%02d:%02d", selectedHour, selectedMinute));
                        }, hour, minute, true);
                timePickerDialog.show();
            }
        });

        // Save button click listener
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String building = buildingSpinner.getSelectedItem().toString();
                String room = roomSpinner.getSelectedItem().toString();
                String time = selectedTimeTextView.getText().toString();

                String message = "楼号: " + building + ",房间号: " + room + ",时间: " + time;

                // Create and show AlertDialog
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("预约成功，您选择的条件是")
                        .setMessage(message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    private void initView() {
        seatView = (StudyRoom) findViewById(R.id.seatView);
        btnJisuanqi = (Button) findViewById(R.id.btn_jisuanqi);
    }
}
